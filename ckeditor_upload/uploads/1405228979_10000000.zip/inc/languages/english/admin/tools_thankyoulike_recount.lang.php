<?php
/**
 * Thank You / Like System Recount English Language Pack
 * 
 * $Id: tools_thankyoulike_recount.lang.php 13 2010-09-16 11:10:10Z - G33K - $
 */

$l['tyl_recount'] = "Thank You/Like Recount";
$l['tyl_recount_desc'] = "Here you can recount the Thank You/Like System data to fix any synchronization problems in your forum.";
$l['tyl_name'] = "Name";
$l['tyl_data_per_page'] = "Data Entries Per Page";
$l['tyl_recount_do_desc'] = "When this is run, the Thank You/Like count for each user and post will be updated to reflect its current live value based on the data in the database.";
$l['tyl_success_thankyoulike_rebuilt'] = "The Thank Yous/Likes have been recounted successfully.";
$l['tyl_confirm_proceed_rebuild'] = "Click \"Proceed\" to continue the Thank You/Like recount process.";

?>